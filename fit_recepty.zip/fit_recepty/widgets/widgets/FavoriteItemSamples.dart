import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavoriteItemSamples extends StatefulWidget {
  @override
  _FavouriteItemSamplesState createState() => _FavouriteItemSamplesState();
}

bool? isChecked = false;
bool? isChecked2 = false;
bool? isChecked3 = false;
bool? isChecked4 = false;
bool? isChecked5 = false;
bool? isChecked6 = false;
bool? isChecked7 = false;

class _FavouriteItemSamplesState extends State<FavoriteItemSamples> {
  @override
  Widget build(BuildContext context) {
    @override
    _savebool() async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isChecked', isChecked!);
      await prefs.setBool('isChecked2', isChecked2!);
      await prefs.setBool('isChecked3', isChecked3!);
      await prefs.setBool('isChecked4', isChecked4!);
      await prefs.setBool('isChecked5', isChecked5!);
      await prefs.setBool('isChecked6', isChecked6!);
      await prefs.setBool('isChecked7', isChecked7!);
    }

    return Column(
      children: [
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/cestoviny.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Cestoviny\ns baklažánovou\nomáčkou a tofu',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked2!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked2 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/keksikovy_kolac.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Rýchly keksíkový koláč\ns pudingovým krémom',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked3!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked3 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/ryža_v_mlieku.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Jablkovo-škoricová ryža\nv kokosovom mlieku',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked4!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked4 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/kari.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Mrkvovo-brokolicové\nkari s kešu orechmi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked5!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked5 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/karfiolova_polievka.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Krémová karfiolová\npolievka bez smotany',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked6!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked6 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/kakaova_rolada.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Fitness kakaová roláda\ns tvarohovou náplňou',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Switch(
                value: isChecked7!,
                activeColor: Color.fromARGB(255, 18, 152, 52),
                onChanged: (newBool) {
                  setState(() {
                    isChecked7 = newBool;
                    _savebool();
                  });
                },
              ),
              Container(
                height: 80,
                width: 80,
                margin: EdgeInsets.only(right: 15),
                child: Image.asset(
                  'assets/images/ovsene_palacinky.jpg',
                  height: 120,
                  width: 120,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  'Raňajkové ovsené\npalacinky s lahodnou\nnáplňou',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ),
              Spacer(),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
