import 'package:flutter/material.dart';

class CategoriesWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'KolacePage');
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
                  Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Image.asset(
                  'assets/images/image1.jpg',
                  width: 70,
                  height: 70,
                ),
                Text(
                  '  Koláče',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'RanajkyPage');
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
                  Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Image.asset(
                  'assets/images/image2.jpg',
                  width: 70,
                  height: 70,
                ),
                Text(
                  '  Raňajky',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'PolievkaPage');
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
                  Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Image.asset('assets/images/image3.jpg', width: 70, height: 70),
                Text(
                  '  Polievky',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'CestovinaPage');
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
                  Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Image.asset(
                  'assets/images/image4.jpg',
                  width: 70,
                  height: 70,
                ),
                Text(
                  '  Cestoviny',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Color.fromARGB(255, 18, 152, 52),
                  ),
                ),
              ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'MasoPage');
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/images/image5.jpg',
                    width: 70,
                    height: 70,
                  ),
                  Text(
                    '  Mäso',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Color.fromARGB(255, 18, 152, 52),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
