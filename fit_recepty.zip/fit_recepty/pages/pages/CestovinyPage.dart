import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class CestovinyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child: Image.asset('assets/images/cestoviny.jpg', height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Cestoviny s baklažánovou omáčkou a tofu',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 25 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 4',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 557 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '400 g celozrnných cetovín;\n400 g lúpaných, sekaných paradajok;\n100 - 200 ml vody;\n50 g čiernych olív;\n1 baklažán;\n360 g marinované bio tofu;\n2 strúčiky cesnaku;\n1 ČL olivového oleja;\n1/2 ČL soli;\n1 ČL provensálskeho korenia;\nštipka čili;\nštipka čerstvo namletého čierneho korenia;\nstrúhaný parmezán.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1.Cestoviny uvaríme vo vriacej, mierne osolenej vode do mäkka.\n2.V menšom hrnci ohrejeme lúpané paradajky, ktoré rozmiešame so 100 - 200 ml vody.\n3.Do paradajkovej omáčky pridáme umytý a nadrobno nakrájaný baklažán, všetky koreniny, soľ, nasekané čierne olivy, prelisované strúčiky cesnaku a dobre zamiešame.\n4.Omáčku varíme pod pokrievkou na miernom plameni 10 - 15 minút, kým baklažán nezmäkne.\n5.Medzitým si na panvici rozohrejeme lyžičku olivového oleja.\n6.Tofu osušíme v papierových obrúskoch, nakrájame ho na malé kocky a opečieme na panvici do zlatista (približne 5 minút).\n7.Napokon tofu vmiešame do baklažánovej omáčky a omáčku servírujeme spolu s precedenými cestovinami.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
