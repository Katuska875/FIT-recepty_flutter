import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class KakaovaroladaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child: Image.asset('assets/images/kakaova_rolada.jpg', height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Fitness kakaová roláda s tvarohovou náplňou',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 25 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 15 kusov',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 102 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Na cesto:\n4 vajcia;\n4 PL xylitolu alebo iného sypkého sladidla;\n2 PL kakaa;\n2 PL celozrnnej hladkej špaldovej múky (prípadne škrobu);\n1 ČL prášku do pečiva;\nštipka soli;\nNa plnku:\n500 g polotučného roztierateľného tvarohu;\n100 g nízkotučného cream cheese;\n20 g strúhaného kokosu;\n1 PL vanilkovej pasty;\n70 g xylitolu alebo iného sypkého sladidla;\n10 g čírej želatíny\nNa polevu:\n50 g horkej čokolády;\n1 ČL kokosového oleja;\n10 g strúhaného kokosu;\n2 banány.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1.Najskôr oddelíme žĺtka od bielkov.\n2.Bielka vyšľaháme spolu so štipkou soli do hustej peny.\n3.Potom k nim opatrne vmiešame všetky zvyšné suroviny na cesto, vrátane žĺtkov.\n4.Hotové cesto vylejeme na veľký plech vystlatý papierom na pečenie a zarovnáme ho pomocou lyžice alebo špatule.\n5.Cesto pečieme 12 minút pri 175 stupňoch (pri programe horné a spodné pečenie).\n6.Medzitým si spolu zmiešame všetky suroviny na plnku. Ak chcete, aby vám plnka pekne zatuhla, odporúčam vmiešať do plnky aj 10 g čírej želatíny.\n7.Upečené cesto pozdĺžne stočíme aj s papierom na pečenie, pokým je ešte teplé.\n8.Cesto necháme vychladnúť, potom ho roztočíme a potrieme po celej ploche pripravenou plnkou.\n9.Ku kraju dlhšej časti uložíme dva očistené banány.\n10.Roládu následne opatrne pozdĺžne zrolujeme.\n11.Čokoládu nalámeme do malej misky, pridáme lyžičku kokosového oleja a dáme ju roztopiť do mikrovlnky (prípadne vo vodnom kúpeli).\n12.Roztopenou čokoládou polejeme vrch rolády, posypeme kokosom a dáme stuhnúť do chladničky aspoň na hodinu.\n13.Roládu odporúčam nakrájať na kúsky po hodine v chladničke (kým ešte čokoláda nie je príliš zatuhnutá).',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
