import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class KekskolacPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child:
                Image.asset('assets/images/keksikovy_kolac.jpg', height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Rýchly keksíkový koláč s pudingovým krémom',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 15 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 8',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 200 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '500 ml mlieka alebo rastlinného nápoja;\n80 g Zlatého klasu;\n100 g xylitolu alebo erytritolu;\n340 g sušienok Gullón Sugar Free Fibre;\novocie podľa chuti;\n1 ČL vanilkovej pasty.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1.V hrnci si zmiešame Zlatý klas so xylitolom, a potom vmiešame aj 500 ml mlieka. Zmes rozmiešame metličkou, aby sme ju zbavili hrdiek.\n2.Puding za občasného miešania privedieme k varu, a potom ho odstavíme.\n3.Do hotového krému môžete primiešať aj tvaroh, ak by ste chceli dosiahnúť krémovejšiu verziu.\n4.Na spodok formy (s rozmermi 20 x 15 cm) poukladáme sušienky.\n5.Na susšienky navrstvíme krém, môžeme pridať ovocie a znova vrstvíme keksíky, krém a ovocie.\n6.Vrchná vrstva by mala pozostávať z keksíkov, ktoré odporúčam pokropiť trochou mlieka, aby zmäkli.\n7.Koláč dáme stuhnúť do chladničky aspoň na 4 hodiny.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
