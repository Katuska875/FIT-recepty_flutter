import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class OvsenepalacinkyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child:
                Image.asset('assets/images/ovsene_palacinky.jpg', height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Raňajkové ovsené palacinky s lahodnou náplňou',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 15 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 10 kusov',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 89 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Palacinky:\n80 g ovsenej múky;\n1/4 ČL soli;\n250 ml nesladeného mandľového mlieka;\n2 vajcia;\n1 PL oleja podľa vlastného výberu;\n1 PL medu;\nNáplň:\n140 g nízkotučného gréckeho jogurtu;\n1 PL arašidového masla;\n1 odmerka vanilkového proteínového prášku;\n1 ČL medu;\nPoleva:\njahody alebo maliny;\nkúsky horkej čokolády;\nroztopená horká čokoláda.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Na palacinky:\n1.V miske spolu zmiešame ovsenú múku a soľ.\n2.V strede urobíme palcom dierku a pridáme do nej zvyšok prísad.\n3.Zmes miešame metličkou, kým nebude cesto obsahovať žiadne hrudky.\n4.Nepriľnavú panvicu potrieme trochou oleja a ohrejeme na strednom plameni.\n5.Panvicu odstavíme z ohňa, nalejeme na ňu jednu naberačku cesta a rýchlo krúžime panvicou, aby sa cesto rovnomerne rozložilo na jej povrchu a vytvorilo tenkú palacinku.\n6.Každú palacinku pečieme asi minútu z každej strany, alebo kým nie je po okrajoch mierne zlatistá.\n7.Palacinky ukladáme rovno na tanier a zakryjeme ich, aby sa nevysušili.\nNa plnku:\n8.Všetky prísady na plnku si spolu rozmiešame v miske dohladka.\n9.Plnku rozdelíme počtom hotových palaciniek. Každú palacinku rovnomerne potrieme krémom a zrolujeme.\n10.Hotové palacinky môžeme ozdobiť jahodami, kúskami horkej čokolády alebo rozpustenou horkou čokoládou.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
