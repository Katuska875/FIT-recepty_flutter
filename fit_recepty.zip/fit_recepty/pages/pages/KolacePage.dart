import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';

class KolacePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          GridView.count(
            childAspectRatio: 0.68,
            physics: NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            shrinkWrap: true,
            children: [
              Container(
                padding: EdgeInsets.only(left: 15, right: 15, top: 10),
                margin: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 18, 152, 52),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            'Novinka',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, 'KekskolacPage');
                      },
                      child: Container(
                        margin: EdgeInsets.all(0),
                        child: Image.asset(
                          'assets/images/keksikovy_kolac.jpg',
                          height: 120,
                          width: 150,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 8),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Rýchly keksíkový koláč s pudingovým krémom',
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 18, 152, 52),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '',
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 18, 152, 52),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Čas príprvy: 15 minút',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color.fromARGB(255, 18, 152, 52),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(left: 15, right: 15, top: 10),
                margin: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '',
                          style: TextStyle(fontSize: 20),
                        ),
                      ],
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, 'KakaovaroladaPage');
                      },
                      child: Container(
                        margin: EdgeInsets.all(0),
                        child: Image.asset(
                          'assets/images/kakaova_rolada.jpg',
                          height: 120,
                          width: 150,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 8),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Fitness kakaová roláda s tvarohovou náplňou',
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 18, 152, 52),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(bottom: 0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '',
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 18, 152, 52),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Čas príprvy: 25 minút',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color.fromARGB(255, 18, 152, 52),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
