import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class KariPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child: Image.asset('assets/images/kari.jpg', height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Mrkvovo-brokolicové kari s kešu orechami',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 30 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 4',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 546 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '400 g mrkvy;\n400 g brokolice;\n400 ml kokosového mlieka (hustý typ z plechovky);\n70 g kešu orechov;\n70 g paradajkového pretlaku;\n2 ČL kari korenia (alebo 2 PL žltej kari pasty);\n1/2 ČL korenia garam masala;\n3/4 ČL soli;\nštipka kurkumy;\n2 strúčiky cesnaku;\n200 g ryže SOS Basmati;\n500 ml vody;\n1/2 ČL soli\nčerstvý koriander.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1.Ryžu dobre preplachneme a v menšom hrnci ju zalejeme s 500 ml vody, pridáme 1/2 ČL soli a varíme ju prikrytú na slabom plameni približne 13 minút.\n2.Kým sa ryža varí, v hrnci si zmiešame kokosové mlieko s paradajkovým pretlakom, koreninami, soľou a zmes privedieme k varu.\n3.Potom do hrnca pridáme umytú a nadrobno nakrájanú brokolicu, na tenké pásiky nakrájanú mrkvu, prelisované strúčiky cesnaku a kešu orechy.\n4.Zeleninu varíme v omáčke za občasného miešania približne 15 minút.\n5.Potom približne 1/5 zmesi priamo v hrnci rozmixujeme ponorným tyčovým mixérom, aby sme omáčku zahustili.\n6.Zeleninovú zmes ešte dobre rozmiešame a necháme prevrieť.\n7.Hotové jedlo podávame s uvarenou ryžou a na záver odporúčam posypať čerstvým koriandrom.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
