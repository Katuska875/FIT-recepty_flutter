import 'package:flutter/material.dart';
import 'package:prog1m/widgets/ItemAppBar.dart';
import 'package:prog1m/widgets/ItemBottomNavBar.dart';

class KarfiolpolievkaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDECF2),
      body: ListView(
        children: [
          ItemAppBar(),
          Padding(
            padding: EdgeInsets.all(10),
            child: Image.asset('assets/images/karfiolova_polievka.jpg',
                height: 300),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Krémová karfiolová polievka bez smotany',
              style: TextStyle(
                fontSize: 28,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              'Čas prípravy: 25 minút',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 5, bottom: 10),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet porcií: 6',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Počet kalórií (1 porcia): 120 kcal',
              style: TextStyle(
                fontSize: 20,
                color: Color.fromARGB(255, 18, 152, 52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Text(
              'Ingrediencie:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1 karfiol (cca 800 g);\n2 zemiaky (cca 300 g);\n3 - 4 l zeleninového vývaru;\n2 strúčiky cesnaku;\n3/4 ČL soli;\n1/4 ČL čerstvo namletého čierneho korenia;\n2 strúhaný syr.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
            child: Text(
              'Postup:',
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontSize: 19,
                  color: Color.fromARGB(255, 18, 152, 52),
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Text(
              '1.Karfiol a zemiaky očistíme a nakrájame na malé kúsky.\n2.Zeleninu zalejeme zeleninovým vývarom tak, aby voda pretŕčala zopár cm nad zeleninu. Pokojne pridajte viac ako 4 l vývaru, prípadne vody.\n3.Do polievky pridáme aj očistené strúčiky cesnaku, soľ, korenie a varíme ju, pokým zelenina nezmäkne (približne 15 až 20 minút).\n4.Potom polievku rozmixujeme tyčovým mixérom dohladka.\n5.Polievku môžeme podávať posypanú strúhaným syrom.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 16,
                color: Color.fromARGB(255, 18, 152, 52),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: ItemBottomNavBar(),
    );
  }
}
