import 'package:flutter/material.dart';
import 'package:prog1m/widgets/FavoriteAppBar.dart';
import 'package:prog1m/widgets/FavoriteItemSamples.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavouritePage extends StatefulWidget {
  @override
  _FavouritePageState createState() => _FavouritePageState();
}

class _FavouritePageState extends State<FavouritePage> {
  @override
  void initState() {
    _loadData();
    super.initState();
  }

  _loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      isChecked = prefs.getBool('isChecked');
      isChecked2 = prefs.getBool('isChecked2');
      isChecked3 = prefs.getBool('isChecked3');
      isChecked4 = prefs.getBool('isChecked4');
      isChecked5 = prefs.getBool('isChecked5');
      isChecked6 = prefs.getBool('isChecked6');
      isChecked7 = prefs.getBool('isChecked7');
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          FavoriteAppBar(),
          Container(
            height: 1000,
            padding: EdgeInsets.only(top: 15),
            decoration: BoxDecoration(
              color: Color(0xFFEDECF2),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(35),
                topRight: Radius.circular(35),
              ),
            ),
            child: Column(
              children: [
                FavoriteItemSamples(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
